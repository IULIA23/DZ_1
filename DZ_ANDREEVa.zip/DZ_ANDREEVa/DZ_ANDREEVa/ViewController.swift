//
//  ViewController.swift
//  DZ_ANDREEVa
//
//  Created by Юлия Андреева on 01.11.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func myLoginTextField(_ sender: UITextField) {
    }
    @IBOutlet weak var myLabel: UILabel!
    
    @IBAction func myPasswordTextField(_ sender: UITextField) {
    }
    @IBAction func myButton(_ sender: UIButton) {
    }
}

